"""
Gaming POD Weekly Agent
Corre cada lunes via GitHub Actions:
1. Detecta top 3 tendencias gaming con búsqueda web
2. Genera 3 diseños por tendencia
3. Genera imágenes con Ideogram API
4. Manda email con todo listo para subir a Redbubble
"""

import os, json, re, smtplib, requests
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from datetime import datetime

ANTHROPIC_API = "https://api.anthropic.com/v1/messages"
IDEOGRAM_API  = "https://api.ideogram.ai/generate"

ANTHROPIC_KEY = os.environ["ANTHROPIC_API_KEY"]
IDEOGRAM_KEY  = os.environ["IDEOGRAM_API_KEY"]
GMAIL_USER    = os.environ["GMAIL_USER"]
GMAIL_PASS    = os.environ["GMAIL_APP_PASSWORD"]
EMAIL_TO      = os.environ["EMAIL_TO"]

HEADERS_AI = {
    "Content-Type": "application/json",
    "x-api-key": ANTHROPIC_KEY,
    "anthropic-version": "2023-06-01"
}

def claude(system, user, use_search=False):
    body = {
        "model": "claude-haiku-4-5-20251001",
        "max_tokens": 1000,
        "system": system,
        "messages": [{"role": "user", "content": user}]
    }
    if use_search:
        body["tools"] = [{"type": "web_search_20250305", "name": "web_search"}]
    r = requests.post(ANTHROPIC_API, headers=HEADERS_AI, json=body)
    r.raise_for_status()
    text = "".join(b.get("text","") for b in r.json()["content"] if b.get("type")=="text")
    clean = re.sub(r"```json|```","", text).strip()
    return json.loads(clean)

def get_trends():
    today = datetime.now().strftime("%Y-%m-%d")
    return claude(
        f"""Hoy es {today}. Eres experto en tendencias gaming y print-on-demand.
Usa web_search para encontrar los juegos y tendencias gaming MÁS populares AHORA.
Busca en Steam, Twitch y Reddit gaming.
Responde SOLO JSON sin markdown:
{{"trends":[{{"name":"nombre","reason":"por qué trending (5 palabras)","score":85}}]}}
Devuelve exactamente 3 tendencias ordenadas por score.""",
        "Busca las 3 tendencias gaming más populares hoy y devuelve el JSON.",
        use_search=True
    )

def get_designs(trend):
    return claude(
        """Experto en print-on-demand para Redbubble y gaming.
Responde SOLO JSON sin markdown:
{"designs":[{"title":"nombre","description":"descripción visual breve","products":["Camiseta","Taza","Sticker"],"tags":["t1","t2","t3","t4","t5","t6","t7","t8"],"imagePrompt":"detailed english prompt for AI image generation, specific art style, colors, composition, t-shirt design ready","margin":10}]}
Genera exactamente 3 diseños variados: tipográfico, ilustración, pixel art.
Prompts muy específicos y visuales en inglés.""",
        f'Genera 3 diseños para Redbubble sobre: "{trend["name"]}". Contexto: {trend["reason"]}.',
    )

def generate_image(prompt):
    try:
        r = requests.post(
            IDEOGRAM_API,
            headers={"Api-Key": IDEOGRAM_KEY, "Content-Type": "application/json"},
            json={
                "image_request": {
                    "prompt": prompt + ", transparent background, t-shirt design, high resolution, vector style",
                    "aspect_ratio": "ASPECT_1_1",
                    "model": "V_2",
                    "magic_prompt_option": "AUTO"
                }
            }
        )
        r.raise_for_status()
        data = r.json()
        img_url = data["data"][0]["url"]
        img_r = requests.get(img_url)
        img_r.raise_for_status()
        return img_r.content
    except Exception as e:
        print(f"  ⚠ Error generando imagen: {e}")
        return None

def build_email(all_results, date_str):
    html = f"""
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  body {{ font-family: -apple-system, sans-serif; background: #0a0a0f; color: #e2e2f0; margin:0; padding:0; }}
  .container {{ max-width: 680px; margin: 0 auto; padding: 32px 20px; }}
  .header {{ text-align:center; padding: 32px; background: linear-gradient(135deg,#0f0f1a,#12121a); border-radius:16px; margin-bottom:28px; border:1px solid #1e1e2e; }}
  .header h1 {{ margin:0 0 8px; font-size:1.8rem; background:linear-gradient(135deg,#e2e2f0,#00ff88); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }}
  .header p {{ margin:0; color:#6b6b8a; font-size:0.9rem; }}
  .trend-block {{ background:#12121a; border:1px solid #1e1e2e; border-radius:14px; padding:24px; margin-bottom:24px; }}
  .trend-title {{ display:flex; align-items:center; gap:10px; margin-bottom:18px; }}
  .trend-name {{ font-size:1.2rem; font-weight:700; color:#e2e2f0; }}
  .trend-score {{ background:rgba(0,255,136,0.15); border:1px solid rgba(0,255,136,0.3); color:#00ff88; padding:3px 10px; border-radius:20px; font-size:0.75rem; font-family:monospace; }}
  .design-card {{ background:#0d0d18; border:1px solid #1e1e2e; border-radius:10px; padding:18px; margin-bottom:14px; }}
  .design-title {{ font-size:1rem; font-weight:700; color:#e2e2f0; margin:0 0 8px; }}
  .design-desc {{ color:#6b6b8a; font-size:0.83rem; line-height:1.5; margin:0 0 12px; }}
  .tags {{ display:flex; flex-wrap:wrap; gap:6px; margin-bottom:12px; }}
  .tag {{ background:rgba(0,255,136,0.08); border:1px solid rgba(0,255,136,0.25); color:#00ff88; padding:2px 9px; border-radius:16px; font-size:0.7rem; font-family:monospace; }}
  .prompt-box {{ background:#070710; border:1px solid #1e1e2e; border-radius:8px; padding:12px; margin-bottom:12px; }}
  .prompt-label {{ color:#6b6b8a; font-size:0.68rem; font-family:monospace; margin-bottom:6px; }}
  .prompt-text {{ color:#c4c4e0; font-size:0.78rem; font-family:monospace; line-height:1.5; }}
  .products {{ display:flex; flex-wrap:wrap; gap:6px; }}
  .product {{ background:rgba(124,58,237,0.15); border:1px solid rgba(124,58,237,0.4); color:#a78bfa; padding:2px 10px; border-radius:6px; font-size:0.75rem; }}
  .margin-badge {{ background:rgba(0,255,136,0.1); border:1px solid #00ff88; color:#00ff88; padding:2px 10px; border-radius:6px; font-size:0.75rem; font-family:monospace; font-weight:700; }}
  .steps {{ background:#12121a; border:1px solid #1e1e2e; border-radius:14px; padding:24px; margin-top:8px; }}
  .step {{ display:flex; gap:12px; padding:10px 0; border-bottom:1px solid #1e1e2e; align-items:flex-start; }}
  .step:last-child {{ border-bottom:none; }}
  .step-num {{ background:rgba(0,255,136,0.15); color:#00ff88; width:26px; height:26px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:0.75rem; font-weight:800; flex-shrink:0; text-align:center; line-height:26px; }}
  .step-text {{ color:#6b6b8a; font-size:0.83rem; line-height:1.5; padding-top:3px; }}
  .footer {{ text-align:center; margin-top:28px; color:#444; font-size:0.75rem; }}
  img.design-img {{ width:100%; border-radius:8px; margin-bottom:12px; border:1px solid #1e1e2e; }}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div style="font-size:0.72rem;font-family:monospace;color:#00ff88;letter-spacing:0.2em;margin-bottom:10px;">▶ REPORTE SEMANAL AUTOMATIZADO</div>
    <h1>🎮 Gaming POD Agent</h1>
    <p>Semana del {date_str} — {sum(len(r['designs']) for r in all_results)} diseños listos para Redbubble</p>
  </div>
"""
    image_attachments = []
    img_counter = 0

    for trend_result in all_results:
        trend = trend_result["trend"]
        designs = trend_result["designs"]
        images  = trend_result["images"]

        html += f"""
  <div class="trend-block">
    <div class="trend-title">
      <span style="font-size:1.4rem">🔥</span>
      <span class="trend-name">{trend['name']}</span>
      <span class="trend-score">Score {trend['score']}</span>
    </div>
    <p style="color:#6b6b8a;font-size:0.82rem;margin:0 0 18px;">{trend['reason']}</p>
"""
        for i, design in enumerate(designs):
            img_data = images[i] if i < len(images) else None
            cid = f"design_{img_counter}"
            img_counter += 1

            html += f"""
    <div class="design-card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
        <div class="design-title">{design['title']}</div>
        <span class="margin-badge">+${design['margin']}/venta</span>
      </div>
      <p class="design-desc">{design['description']}</p>
"""
            if img_data:
                html += f'      <img class="design-img" src="cid:{cid}" alt="{design["title"]}">\n'
                image_attachments.append((cid, img_data))

            html += f"""
      <div class="tags">{''.join(f'<span class="tag">#{t}</span>' for t in design['tags'])}</div>
      <div class="prompt-box">
        <div class="prompt-label">🖼️ PROMPT PARA IDEOGRAM / LEONARDO AI</div>
        <div class="prompt-text">{design['imagePrompt']}</div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
        <div class="products">{''.join(f'<span class="product">{p}</span>' for p in design['products'])}</div>
      </div>
    </div>
"""
        html += "  </div>\n"

    html += """
  <div class="steps">
    <h3 style="color:#e2e2f0;margin:0 0 16px;font-size:0.95rem;">🗺️ Cómo subir a Redbubble (15–20 min total)</h3>
    <div class="step"><div class="step-num">1</div><div class="step-text">Descarga las imágenes adjuntas en este email (o genera nuevas con los prompts en ideogram.ai)</div></div>
    <div class="step"><div class="step-num">2</div><div class="step-text">Ve a redbubble.com → Add New Work → sube la imagen</div></div>
    <div class="step"><div class="step-num">3</div><div class="step-text">Copia el título y los tags de este email → pégalos en Redbubble</div></div>
    <div class="step"><div class="step-num">4</div><div class="step-text">Activa los productos recomendados y define tu margen → Publica</div></div>
    <div class="step"><div class="step-num">5</div><div class="step-text">Repite para cada diseño. El agente te mandará nuevos diseños el próximo lunes.</div></div>
  </div>
  <div class="footer">Gaming POD Agent • Generado automáticamente • GitHub Actions</div>
</div>
</body>
</html>
"""
    return html, image_attachments

def send_email(html_body, image_attachments, date_str):
    msg = MIMEMultipart("related")
    msg["Subject"] = f"🎮 Gaming POD — {len(image_attachments)} diseños listos para Redbubble ({date_str})"
    msg["From"]    = GMAIL_USER
    msg["To"]      = EMAIL_TO

    alt = MIMEMultipart("alternative")
    msg.attach(alt)
    alt.attach(MIMEText(html_body, "html"))

    for cid, img_data in image_attachments:
        img = MIMEImage(img_data)
        img.add_header("Content-ID", f"<{cid}>")
        img.add_header("Content-Disposition", "inline")
        msg.attach(img)

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
        smtp.login(GMAIL_USER, GMAIL_PASS)
        smtp.sendmail(GMAIL_USER, EMAIL_TO, msg.as_string())

def main():
    date_str = datetime.now().strftime("%d/%m/%Y")
    print("🔍 Buscando tendencias gaming...")
    trend_data = get_trends()
    trends = trend_data.get("trends", [])
    print(f"✓ {len(trends)} tendencias encontradas: {[t['name'] for t in trends]}")

    all_results = []
    for trend in trends:
        print(f"\n🎨 Generando diseños para: {trend['name']}")
        design_data = get_designs(trend)
        designs = design_data.get("designs", [])
        print(f"  ✓ {len(designs)} diseños generados")

        images = []
        for i, d in enumerate(designs):
            print(f"  🖼 Generando imagen {i+1}/{len(designs)}: {d['title']}")
            img = generate_image(d["imagePrompt"])
            images.append(img)
            if img:
                print(f"     ✓ Imagen generada")

        all_results.append({"trend": trend, "designs": designs, "images": images})

    print("\n📧 Construyendo y enviando email...")
    html, attachments = build_email(all_results, date_str)
    send_email(html, attachments, date_str)
    total = sum(len(r["designs"]) for r in all_results)
    print(f"✅ Email enviado con {total} diseños y {len(attachments)} imágenes generadas.")

if __name__ == "__main__":
    main()
