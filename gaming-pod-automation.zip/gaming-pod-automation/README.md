# 🎮 Gaming POD Agent — Automatización Semanal
**Powered by Google Gemini (GRATIS) + Ideogram + GitHub Actions**

Cada lunes a las 8am el agente:
1. Detecta las 3 tendencias gaming más populares
2. Genera 3 diseños por tendencia (9 en total)
3. Genera las imágenes con Ideogram AI
4. Te manda todo por email listo para subir a Redbubble

Tu trabajo: **15–20 min los lunes** subiendo a Redbubble.

---

## ⚙️ Configuración (una sola vez, ~15 minutos)

### Paso 1 — Sube este proyecto a GitHub
1. Ve a github.com → New repository → nombre: `gaming-pod-agent` (privado)
2. Sube todos estos archivos tal cual

### Paso 2 — Obtén tus API Keys

#### 🟢 Google Gemini (GRATIS)
1. Ve a **aistudio.google.com**
2. Inicia sesión con tu cuenta Google
3. Clic en **"Get API Key"** → **"Create API key"**
4. Copia la key (empieza con `AIza...`)

#### 🖼️ Ideogram (imágenes, ~$0.18/semana)
1. Ve a **ideogram.ai** → Sign up gratis
2. Settings → API → Create API Key
3. Añade créditos mínimos (~$5 dura meses)
4. Copia la key

#### 📧 Gmail App Password
1. Ve a **myaccount.google.com** → Seguridad
2. Activa **Verificación en 2 pasos** (si no la tienes)
3. Busca **"Contraseñas de aplicaciones"**
4. Crea una para "Correo" → copia los 16 caracteres

### Paso 3 — Configura los Secrets en GitHub

En tu repositorio: **Settings → Secrets and variables → Actions → New repository secret**

| Secret | Valor |
|--------|-------|
| `GEMINI_API_KEY` | tu key de Google AI Studio |
| `IDEOGRAM_API_KEY` | tu key de Ideogram |
| `GMAIL_USER` | tu@gmail.com |
| `GMAIL_APP_PASSWORD` | contraseña de app (16 chars) |
| `EMAIL_TO` | email donde recibes los diseños |

### Paso 4 — Activa GitHub Actions
- Pestaña **Actions** en tu repositorio
- Clic en **"I understand my workflows, enable them"**

### Paso 5 — Prueba ahora mismo
- **Actions → "Gaming POD Agent" → "Run workflow"**
- En ~3–5 minutos llega el email con 9 diseños

---

## 💰 Costo real por semana

| Concepto | Costo |
|----------|-------|
| Google Gemini 1.5 Flash | **Gratis** |
| GitHub Actions | **Gratis** |
| Gmail | **Gratis** |
| Ideogram (9 imágenes × $0.02) | ~$0.18 |
| **Total por semana** | **~$0.18** |

**~$0.72/mes** para tener 36 diseños nuevos cada mes en Redbubble.

---

## 📅 Qué recibes cada lunes

- 3 tendencias gaming detectadas
- 9 diseños con título, descripción, tags y prompts
- 9 imágenes generadas listas para subir
- Guía de pasos para publicar

---

## ❓ Problemas frecuentes

**No llega el email:**
Revisa que el Gmail App Password sea correcto y que tengas verificación en 2 pasos activa.

**Error en Ideogram:**
Verifica que tengas saldo en tu cuenta de Ideogram.

**Error en Gemini:**
Confirma que la key empiece con `AIza` y que no tenga espacios.
