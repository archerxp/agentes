# 🎮 Gaming POD Agent — Automatización Semanal

Cada lunes a las 8am el agente:
1. Busca las 3 tendencias gaming más populares en internet
2. Genera 3 diseños por tendencia (9 diseños en total)
3. Genera las imágenes con Ideogram AI
4. Te manda todo por email listo para subir a Redbubble

## ⚙️ Configuración (una sola vez, ~20 minutos)

### Paso 1 — Sube este proyecto a GitHub
1. Crea un repositorio nuevo en github.com (puede ser privado)
2. Sube todos estos archivos

### Paso 2 — Obtén tus API keys

**Anthropic (Claude):**
- Ve a console.anthropic.com
- API Keys → Create Key
- Copia la key

**Ideogram (imágenes):**
- Ve a ideogram.ai → Sign up gratis
- Settings → API → Create API Key
- Plan gratuito incluye créditos iniciales (~$5)
- Cada imagen cuesta ~$0.02 → 9 imágenes/semana = $0.18/semana

**Gmail (para enviar el email):**
- Ve a myaccount.google.com → Seguridad
- Verificación en 2 pasos → actívala
- Contraseñas de aplicaciones → crear una para "Mail"
- Copia la contraseña de 16 caracteres

### Paso 3 — Configura los Secrets en GitHub
En tu repositorio: Settings → Secrets → Actions → New repository secret

Agrega estos 5 secrets:

| Nombre | Valor |
|--------|-------|
| `ANTHROPIC_API_KEY` | tu key de Anthropic |
| `IDEOGRAM_API_KEY` | tu key de Ideogram |
| `GMAIL_USER` | tu@gmail.com |
| `GMAIL_APP_PASSWORD` | contraseña de app de 16 chars |
| `EMAIL_TO` | donde quieres recibir el email |

### Paso 4 — Activa GitHub Actions
- Ve a la pestaña "Actions" en tu repositorio
- Haz clic en "I understand my workflows, go ahead and enable them"

### Paso 5 — Prueba manual
- Actions → "Gaming POD Agent — Semanal" → "Run workflow"
- En ~5 minutos recibes el email con los diseños

## 💰 Costos semanales

| Concepto | Costo |
|----------|-------|
| GitHub Actions | Gratis |
| Claude Haiku (tendencias + diseños) | ~$0.05 |
| Ideogram (9 imágenes) | ~$0.18 |
| Gmail | Gratis |
| **Total por semana** | **~$0.23** |

## 📅 Qué recibes cada lunes

- 3 tendencias gaming detectadas en internet ese día
- 9 diseños completos con título, descripción y tags
- 9 imágenes generadas listas para subir
- Guía de pasos para publicar en Redbubble

Tu trabajo: 15–20 minutos subiendo a Redbubble.
